(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[407],{1291:function(e,t,n){"use strict";n.d(t,{Z:function(){return l}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]])},7158:function(e,t,n){"use strict";n.d(t,{Z:function(){return l}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},5817:function(e,t,n){"use strict";n.d(t,{Z:function(){return l}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]])},9883:function(e,t,n){"use strict";n.d(t,{Z:function(){return l}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]])},4280:function(e,t,n){"use strict";n.d(t,{Z:function(){return l}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("RefreshCw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]])},1827:function(e,t,n){"use strict";n.d(t,{Z:function(){return l}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]])},3589:function(e,t,n){"use strict";n.d(t,{Z:function(){return l}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("SquarePen",[["path",{d:"M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",key:"1m0v6g"}],["path",{d:"M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z",key:"ohrbg2"}]])},5367:function(e,t,n){"use strict";n.d(t,{Z:function(){return l}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},572:function(e,t,n){Promise.resolve().then(n.bind(n,3459))},3459:function(e,t,n){"use strict";n.r(t),n.d(t,{default:function(){return c}});var r=n(7437),l=n(2265),a=n(5429),i=n(2621);function c(){let[e,t]=(0,l.useState)([]),[n,c]=(0,l.useState)(!0),[s,o]=(0,l.useState)(""),{toast:u}=(0,i.pm)(),d=async function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"";c(!0);try{let n=await fetch("/api/tables/activity_logs?".concat(e?"search=".concat(e):"","&sortBy=created_at&sortOrder=desc")),r=await n.json();t(r.data||[])}catch(e){u({title:"Error",description:"Failed to fetch logs",variant:"destructive"})}finally{c(!1)}};return(0,l.useEffect)(()=>{d()},[]),(0,r.jsxs)("div",{className:"space-y-6",children:[(0,r.jsxs)("div",{children:[(0,r.jsx)("h1",{className:"text-3xl font-bold text-slate-900",children:"Activity Logs"}),(0,r.jsx)("p",{className:"mt-2 text-slate-600",children:"View all system activity and changes"})]}),(0,r.jsx)(a.w,{data:e,columns:[{key:"action",label:"Action"},{key:"table_name",label:"Table"},{key:"ip_address",label:"IP Address"},{key:"created_at",label:"Timestamp",render:e=>new Date(e).toLocaleString()}],onEdit:()=>{},onDelete:()=>{},onAdd:()=>{},onRefresh:()=>d(s),onSearch:e=>{o(e),d(e)},onExport:()=>{},loading:n,searchValue:s})]})}},2210:function(e,t,n){"use strict";n.d(t,{F:function(){return l},e:function(){return a}});var r=n(2265);function l(...e){return t=>e.forEach(e=>{"function"==typeof e?e(t):null!=e&&(e.current=t)})}function a(...e){return r.useCallback(l(...e),e)}},7256:function(e,t,n){"use strict";n.d(t,{g7:function(){return i}});var r=n(2265),l=n(2210),a=n(7437),i=r.forwardRef((e,t)=>{let{children:n,...l}=e,i=r.Children.toArray(n),s=i.find(o);if(s){let e=s.props.children,n=i.map(t=>t!==s?t:r.Children.count(e)>1?r.Children.only(null):r.isValidElement(e)?e.props.children:null);return(0,a.jsx)(c,{...l,ref:t,children:r.isValidElement(e)?r.cloneElement(e,void 0,n):null})}return(0,a.jsx)(c,{...l,ref:t,children:n})});i.displayName="Slot";var c=r.forwardRef((e,t)=>{let{children:n,...a}=e;if(r.isValidElement(n)){let e,i;let c=(e=Object.getOwnPropertyDescriptor(n.props,"ref")?.get)&&"isReactWarning"in e&&e.isReactWarning?n.ref:(e=Object.getOwnPropertyDescriptor(n,"ref")?.get)&&"isReactWarning"in e&&e.isReactWarning?n.props.ref:n.props.ref||n.ref;return r.cloneElement(n,{...function(e,t){let n={...t};for(let r in t){let l=e[r],a=t[r],i=/^on[A-Z]/.test(r);i?l&&a?n[r]=(...e)=>{a(...e),l(...e)}:l&&(n[r]=l):"style"===r?n[r]={...l,...a}:"className"===r&&(n[r]=[l,a].filter(Boolean).join(" "))}return{...e,...n}}(a,n.props),ref:t?(0,l.F)(t,c):c})}return r.Children.count(n)>1?r.Children.only(null):null});c.displayName="SlotClone";var s=({children:e})=>(0,a.jsx)(a.Fragment,{children:e});function o(e){return r.isValidElement(e)&&e.type===s}},9213:function(e,t,n){"use strict";n.d(t,{j:function(){return a}});let r=e=>"boolean"==typeof e?"".concat(e):0===e?"0":e,l=function(){for(var e,t,n=0,r="";n<arguments.length;)(e=arguments[n++])&&(t=function e(t){var n,r,l="";if("string"==typeof t||"number"==typeof t)l+=t;else if("object"==typeof t){if(Array.isArray(t))for(n=0;n<t.length;n++)t[n]&&(r=e(t[n]))&&(l&&(l+=" "),l+=r);else for(n in t)t[n]&&(l&&(l+=" "),l+=n)}return l}(e))&&(r&&(r+=" "),r+=t);return r},a=(e,t)=>n=>{var a;if((null==t?void 0:t.variants)==null)return l(e,null==n?void 0:n.class,null==n?void 0:n.className);let{variants:i,defaultVariants:c}=t,s=Object.keys(i).map(e=>{let t=null==n?void 0:n[e],l=null==c?void 0:c[e];if(null===t)return null;let a=r(t)||r(l);return i[e][a]}),o=n&&Object.entries(n).reduce((e,t)=>{let[n,r]=t;return void 0===r||(e[n]=r),e},{}),u=null==t?void 0:null===(a=t.compoundVariants)||void 0===a?void 0:a.reduce((e,t)=>{let{class:n,className:r,...l}=t;return Object.entries(l).every(e=>{let[t,n]=e;return Array.isArray(n)?n.includes({...c,...o}[t]):({...c,...o})[t]===n})?[...e,n,r]:e},[]);return l(e,s,u,null==n?void 0:n.class,null==n?void 0:n.className)}}},function(e){e.O(0,[395,93,971,864,744],function(){return e(e.s=572)}),_N_E=e.O()}]);