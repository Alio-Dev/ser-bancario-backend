(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[931],{307:function(e,r,t){Promise.resolve().then(t.bind(t,7139))},7139:function(e,r,t){"use strict";t.r(r),t.d(r,{default:function(){return u}});var n=t(7437),s=t(2265),o=t(4033);function u(){let e=(0,o.useRouter)();return(0,s.useEffect)(()=>{e.push("/dashboard")},[e]),(0,n.jsx)("div",{className:"flex h-screen items-center justify-center",children:(0,n.jsx)("div",{className:"text-lg text-slate-600",children:"Redirecting to dashboard..."})})}},622:function(e,r,t){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var n=t(2265),s=Symbol.for("react.element"),o=Symbol.for("react.fragment"),u=Object.prototype.hasOwnProperty,c=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,f={key:!0,ref:!0,__self:!0,__source:!0};function i(e,r,t){var n,o={},i=null,a=null;for(n in void 0!==t&&(i=""+t),void 0!==r.key&&(i=""+r.key),void 0!==r.ref&&(a=r.ref),r)u.call(r,n)&&!f.hasOwnProperty(n)&&(o[n]=r[n]);if(e&&e.defaultProps)for(n in r=e.defaultProps)void 0===o[n]&&(o[n]=r[n]);return{$$typeof:s,type:e,key:i,ref:a,props:o,_owner:c.current}}r.Fragment=o,r.jsx=i,r.jsxs=i},7437:function(e,r,t){"use strict";e.exports=t(622)},4033:function(e,r,t){e.exports=t(290)}},function(e){e.O(0,[971,864,744],function(){return e(e.s=307)}),_N_E=e.O()}]);