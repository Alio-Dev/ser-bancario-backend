"use strict";exports.id=219,exports.ids=[219],exports.modules={9803:(e,t,a)=>{a.d(t,{Z:()=>l});var r=a(2125);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]])},9490:(e,t,a)=>{a.d(t,{Z:()=>l});var r=a(2125);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let l=(0,r.Z)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]])},3618:(e,t,a)=>{a.d(t,{f:()=>s});var r=a(9885),l=a(3979),d=a(80),o=r.forwardRef((e,t)=>(0,d.jsx)(l.WV.label,{...e,ref:t,onMouseDown:t=>{let a=t.target;a.closest("button, input, select, textarea")||(e.onMouseDown?.(t),!t.defaultPrevented&&t.detail>1&&t.preventDefault())}}));o.displayName="Label";var s=o}};